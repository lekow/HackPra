#!/usr/bin/env python

# Format: TRANSFER AMOUNT $1000000 REASON Salary Jan. 2016 DEST #78384 END

from Crypto.Cipher import AES
import base64
import sys


_key = 'not the real key'
_iv  = 'not the real  iv'


def cbc_encrypt(msg):
	return AES.new(_key, AES.MODE_CBC, _iv).encrypt(msg)

def cbc_decrypt(msg):
	return AES.new(_key, AES.MODE_CBC, _iv).decrypt(msg)


if __name__ == '__main__':
	try:
		l = sys.stdin.readline().strip()
		l = base64.b64decode(l)
		l = cbc_decrypt(l)
		r = l.split()
		if r[0] != 'TRANSFER' or r[-1] != 'END':
			raise ValueError

		amount = r[r.index('AMOUNT') + 1]
		dest   = r[r.index('DEST') + 1]

		print 'Successfully transferred ' + amount + ' to account ' + dest + '!'
	except:
		print 'Malformed transfer request!'
