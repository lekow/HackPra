#!/bin/sh

for i in 1 2 3; do
	cat msg.txt | openssl rsautl -encrypt -raw -pubin -inkey pk$i.pem > msg$i.bin
done
